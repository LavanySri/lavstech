dirlocation=$(dirname $0)
. $dirlocation/vision.properties
export MAPR_TICKETFILE_LOCATION=${MAPR_TICKETFILE_LOCATION}

EMAIL_SUB="Prod Vision trigger failed"
#cd $landing
filelist=`ls $landing`
cd $result
DATETIME="`date '+%Y%m%d%H%M%S'`"
logname="vision_trigger"_${DATETIME}
echo "NA|NA|NA|${DATE}|${TIME}|vision Script triggered|Pass" &>> ${stat_log_dir}${logname}
echo "**************Generating file with list of strings" &>> ${log_dir}${logname}
# list of string patterns stored here
create_stringpattern()
{
hive -e "select file_naming_convention from groupretiree_vision.client_file_info;">$result/string_patterns.txt
if [ $? -ne 0 ] #echo log if
    then 
    echo "NA|NA|NA|${DATE}|${TIME}|create_stringpattern failed|Fail" &>> ${stat_log_dir}${logname}
    echo "**************Unable to generate string_pattern.txt"
    sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "Unable to generate string_patterns.txt from groupretiree_vision.client_file_info table"     
    exit 0
fi
}
create_stringpattern &>> ${log_dir}${logname}
echo "NA|NA|NA|${DATE}|${TIME}|string_pattern.txt ready|Pass" &>> ${stat_log_dir}${logname}
#take the list of string patterns we need to look
echo "**************File with list of strings generated in result directory" &>> ${log_dir}${logname}

query_clientsreference()
{
	#read foldername and vision type from hive table
	echo "************** Quering clients reference table"
	#read foldername visiontype <<< $(hive -e "select folder_name,layout groupretiree_vision.client_file_info where file_naming_convention='$stringmatch';")
	hive -e "select folder_name,layout from groupretiree_vision.client_file_info where file_naming_convention='$stringmatch';">$result/query_client_info.txt
	if [ $? -ne 0 ] #echo log if
              then 
              echo "$f|NA|NA|${DATE}|${TIME}|client_file_info query failed|Fail" &>> ${stat_log_dir}${logname}
              echo "**************Unable to query client_file_info table"
              sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "Unable to query client_file_info table"     
              exit 0
    fi
	echo "************** Quering client_file_info successful"
	read foldername visiontype < $result/query_client_info.txt
	if [ $? -ne 0 ] #echo log if
              then 
              echo "$f|NA|NA|${DATE}|${TIME}|reading query_client_info.txt failed|Fail" &>> ${stat_log_dir}${logname}
              echo "**************Unable to read from query_client_info.txt"
              sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "Unable to read from query_client_info.txt"     
              exit 0
    fi
	echo "**************vision type is $visiontype and Folder name is $foldername"  &>> ${log_dir}${logname}
}


movefile_loaddata()
{
	#client folder is already there. check for year and month. If either one of them don't exists create the folders and move the file to the particular month folder and then call the alter script
	cd $location/$foldername
        if [[ -d $YEAR ]] ; then
        	echo "**************Year folder exists"
        	cd $location/$foldername/$YEAR
        	if [[ -d $MONTH ]] ; then
        		echo "**************Month folder exists. Moving to tempfolder"
				mkdir -p $location/$foldername/temp
        	    mv $landing/$f $location/$foldername/temp
				#mv $landing/$f $location/$foldername/$YEAR/$MONTH
    		    if [ $? -ne 0 ] #echo log if
                then 
                echo "$f|$foldername|$visiontype|${DATE}|${TIME}|Unable to move file|Fail" &>> ${stat_log_dir}${logname}
                echo "**************Moving $f from landing to temp folder failed"
                sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "Moving $f from landing to month folder failed"     
                exit 0
                fi
        		echo "$f|$foldername|$visiontype|${DATE}|${TIME}|file moved|Pass" &>> ${stat_log_dir}${logname}
        		echo "**************$f successfully moved"
        	else
        		echo "**************creating month directory"
        		mkdir $MONTH
        		echo "$f|$foldername|$visiontype|${DATE}|${TIME}|month directory created|Pass" &>> ${stat_log_dir}${logname}
        		echo "**************Moving $f to temp"		
				mkdir -p $location/$foldername/temp
				mv $landing/$f $location/$foldername/temp
				#mv $landing/$f $location/$foldername/$YEAR/$MONTH
				if [ $? -ne 0 ] #echo log if
                then 
                echo "$f|$foldername|$visiontype|${DATE}|${TIME}|Unable to move file|Fail" &>> ${stat_log_dir}${logname}
                echo "**************Moving $f from landing to month folder failed"
                sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "Moving $f from landing to month folder failed"     
                exit 0
                fi
        		echo "$f|$foldername|$visiontype|${DATE}|${TIME}|file moved|Pass" &>> ${stat_log_dir}${logname}
        		echo "**************$f successfully moved"
			fi
			#adding file check
			file_extention_check_alter_table $f $foldername $visiontype $logname &>> ${log_dir}${logname}
			if [ $? -ne 0 ] #echo log if
            	    then 
            	    sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "Failure in the eyemed_rawtable.sh script"     
                  exit 0
   			fi	
#getting src_btch_id for vision claims
			src_btch_id_claims $file_type
			if [ $? -ne 0 ] #echo log if
            	    then 
            	    sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "Failure while getting src_btch_id"     
                  exit 0
   			fi	
#getting client_name from cilent_file_info to map ORIG_SUB_SRC_SYS field
			client_name=$(hive -S -e  "select client_name from groupretiree_vision.client_file_info where layout='${eyemed_cms}' and folder_name='${foldername}' limit 1;")
  			if [ $? -ne 0 ] #echo log if
            	    then 
            	    sh ${scripts}email_script.sh "Vision Prod:client_name:$foldername Error occured" "$email_send" "$email_receive" "Failure while getting client_name from client_file_info table"     
                  exit 0
   			fi
			echo "client name is " $client_name
#loading vision claims clean data to acc_vision table
			hive -f ${hivescripts}eyemed_cms_claims_insert.hql -d year=$YEAR -d month=$MONTH -d client=$foldername -d client_name=$client_name -d date=$DATE -d src_batch_id=$batch_id
			if [ $? -ne 0 ] #echo log if
               then 
               echo "$f|$foldername|$pbmtype|${DATE}|${TIME}|eyemed_cms_claims_insert.hql failed|Fail" &>> ${stat_log_dir}${logname}
               echo "**************Failed to execute eyemed_cms_claims_insert.hql"
               sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "eyemed_cms_claims_insert.hql script failed"
               exit 0
            fi
#loading distinct fields data into ${client}_prov_raw table 
			hive -f ${hivescripts}eyemed_cms_prov_raw.hql -d year=$YEAR -d month=$MONTH -d client=$foldername
				if [ $? -ne 0 ] #echo log if
					then 
					echo "$f|$foldername|$pbmtype|${DATE}|${TIME}|eyemed_cms_prov_raw.hql failed|Fail" &>> ${stat_log_dir}${logname}
					echo "**************Failed to execute eyemed_cms_prov_raw.hql"
					sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "eyemed_cms_prov_raw.hql failed"
					exit 0
				fi
#retrieving src_batch_id for provider table
			src_btch_id_Provider $file_type_prov
				if [ $? -ne 0 ] #echo log if
            	    then 
            	    sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "Failure while getting src_btch_id"     
					exit 0
				fi
#loading prov_raw table to acc_provider table
		hive -f ${hivescripts}eyemed_cms_provider_insert.hql -d year=$YEAR -d month=$MONTH -d client_name=$client_name -d client=$foldername -d date=$DATE -d src_batch_id=$batch_id
			if [ $? -ne 0 ] #echo log if
               then 
               echo "$f|$foldername|$pbmtype|${DATE}|${TIME}|eyemed_cms_provider_insert.hql failed|Fail" &>> ${stat_log_dir}${logname}
               echo "**************Failed to execute eyemed_cms_provider_insert.hql"
               sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "eyemed_cms_provider_insert.hql failed"
               exit 0
            fi
        else
        	echo "**************creating year and month directory"
        	mkdir -p $YEAR/$MONTH
        	echo "$f|$foldername|$visiontype|${DATE}|${TIME}|directories created|Pass" &>> ${stat_log_dir}${logname}
        	echo "**************Moving temp"
			mkdir -p $location/$foldername/temp
            mv $landing/$f $location/$foldername/temp
			#mv $landing/$f $location/$foldername/$YEAR/$MONTH
            if [ $? -ne 0 ] #echo log if
              then 
              echo "$f|$foldername|$visiontype|${DATE}|${TIME}|Unable to move file|Fail" &>> ${stat_log_dir}${logname}
              echo "**************Moving $f from landing to month folder failed"
              sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "Moving $f from landing to month folder failed"     
              exit 0
            fi
			file_extention_check_alter_table $f $foldername $visiontype $logname &>> ${log_dir}${logname}
			if [ $? -ne 0 ] #echo log if
            	    then 
            	    sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "Failure in the eyemed_rawtable.sh script"     
                  exit 0
   			fi
#getting src_btch_id for vision claims
			src_btch_id_claims $file_type
			if [ $? -ne 0 ] #echo log if
            	    then 
            	    sh ${scripts}email_script.sh "Vision Prod:src_btch_id:$foldername Error occured" "$email_send" "$email_receive" "Failure while getting src_btch_id"     
                  exit 0
   			fi
#getting client_name from cilent_file_info to map ORIG_SUB_SRC_SYS field
			client_name=$(hive -S -e  "select client_name from groupretiree_vision.client_file_info where layout='${eyemed_cms}' and folder_name='${foldername}' limit 1;")
  			if [ $? -ne 0 ] #echo log if
            	    then 
            	    sh ${scripts}email_script.sh "Vision Prod:client_name:$foldername Error occured" "$email_send" "$email_receive" "Failure while getting client_name from client_file_info table"     
                  exit 0
   			fi
			echo "client name is " $client_name
#loading vision claims clean data to acc_vision table
			hive -f ${hivescripts}eyemed_cms_claims_insert.hql -d year=$YEAR -d month=$MONTH -d client=$foldername -d client_name=$client_name -d date=$DATE -d src_batch_id=$batch_id
			if [ $? -ne 0 ] #echo log if
               then 
               echo "$f|$foldername|$pbmtype|${DATE}|${TIME}|eyemed_cms_claims_insert.hql failed|Fail" &>> ${stat_log_dir}${logname}
               echo "**************Failed to execute eyemed_cms_claims_insert.hql"
               sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "eyemed_cms_claims_insert.hql script failed"
               exit 0
            fi
#loading distinct fields data into ${client}_prov_raw table 
			hive -f ${hivescripts}eyemed_cms_prov_raw.hql -d year=$YEAR -d month=$MONTH -d client=$foldername
				if [ $? -ne 0 ] #echo log if
					then 
					echo "$f|$foldername|$pbmtype|${DATE}|${TIME}|eyemed_cms_prov_raw.hql failed|Fail" &>> ${stat_log_dir}${logname}
					echo "**************Failed to execute eyemed_cms_prov_raw.hql"
					sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "eyemed_cms_prov_raw.hql failed"
					exit 0
				fi
#retrieving src_batch_id for provider table
			src_btch_id_Provider $file_type_prov
				if [ $? -ne 0 ] #echo log if
            	    then 
            	    sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "Failure while getting src_btch_id"     
					exit 0
				fi
#loading prov_raw table to acc_provider table
		hive -f ${hivescripts}eyemed_cms_provider_insert.hql -d year=$YEAR -d month=$MONTH -d client=$foldername -d client_name=$client_name -d date=$DATE -d src_batch_id=$batch_id
			if [ $? -ne 0 ] #echo log if
               then 
               echo "$f|$foldername|$pbmtype|${DATE}|${TIME}|eyemed_cms_provider_insert.hql failed|Fail" &>> ${stat_log_dir}${logname}
               echo "**************Failed to execute eyemed_cms_provider_insert.hql"
               sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "eyemed_cms_provider_insert.hql failed"
               exit 0
            fi
	    fi
}

file_extention_check_alter_table()
{	
	file=`ls $location/$foldername/temp`
    echo "************Checking file extension"
	extension="${file##*.}"
	echo "************extension of the file is $extension"
	if [[ $extension == 'gz' ]] ; then
		    echo "************gunzipping $file"
        	gunzip $file
        	if [ $? -ne 0 ] #echo log if
            then 
            echo "$f|$foldername|$visiontype|${DATE}|${TIME}|gunzipping $file|Fail" &>> ${stat_log_dir}${logname}
            echo "**************gunzipping $file failed"
            exit 40
            fi
	elif [[ $extension == 'zip' ]] ; then
            echo "************unzipping $file"
		    unzip $file
		    if [ $? -ne 0 ] #echo log if
            then 
            echo "$f|$foldername|$visiontype|${DATE}|${TIME}|unzipping $file|Fail" &>> ${stat_log_dir}${logname}
            echo "**************unzipping $file failed"
            exit 40
            fi
		    echo "************Removing original zip file"
		    rm $file
	fi
		mv $location/$foldername/temp/$f $location/$foldername/$YEAR/$MONTH
		if [ $? -ne 0 ] #echo log if
             	 then 
             	echo "$f|$foldername|$visiontype|${DATE}|${TIME}|Unable to move file|Fail" &>> ${stat_log_dir}${logname}
             	echo "**************Moving $f from landing to month folder failed"
                sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "Moving $f from landing to month folder failed"     
             	 exit 0
        fi
		echo "$f|$foldername|$visiontype|${DATE}|${TIME}|file moved|Pass" &>> ${stat_log_dir}${logname}
        echo "**************$f successfully moved"
		echo "removing temp folder"
		rm -rf $location/$foldername/temp
        if [ $? -ne 0 ] #echo log if
             	then 
             	echo "$f|$foldername|$visiontype|${DATE}|${TIME}|Unable to remove temp folder|Fail" &>> ${stat_log_dir}${logname}
             	echo "**************Moving $f from landing to month folder failed"
                sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "Moving $f from landing to month folder failed"     
             	 exit 0
        fi   	
        		echo "adding client name to client_lists file"
				grep -q -F $foldername $result/clients_list.txt || echo $foldername >> $result/clients_list.txt   
				if [ $? -ne 0 ] #echo log if
					then 
					echo "$f|$foldername|$visiontype|${DATE}|${TIME}|adding client name to clients_lists file|Fail" &>> ${stat_log_dir}${logname}
					echo "**************moving type2.txt to month folder failed"
					exit 40
				fi     
				echo "************client name added to clients_list.txt file"
        		echo "**************calling alter table script"
			cd $location
            echo $hive_alterpath/$foldername/$YEAR/$MONTH
        		hive -f ${hivescripts}eyemed_cms_alter.hql -d year=$YEAR -d month=$MONTH -d client=$foldername -d path=$hive_alterpath 
        		if [ $? -ne 0 ] #echo log if
             	 then 
              	 echo "$f|$foldername|$visiontype|${DATE}|${TIME}|Adding partition failed|Fail" &>> ${stat_log_dir}${logname}
                 echo "**************Failed to add raw table partition"
                 sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "eyemed_cms_alter.hql failed to add raw table partition"     
                 exit 0
                fi
        		echo "$f|$foldername|$visiontype|${DATE}|${TIME}|Raw table Patition added|Pass" &>> ${stat_log_dir}${logname}
        		echo "**************Partition successfully added"   
				echo "************Files successfully moved"
}

src_btch_id_claims()
{
segment1=$(hive -S -e  "select Numeric_Value from groupretiree_vision.src_btch_id where Segment_types='segment1' and Lookup_Value='${vision}';")
	if [ $? -ne 0 ] #echo log if
		then 
		echo "NA|NA|NA|${DATE}|${TIME}|retrieving segment1 value from hive|Fail" &>> ${stat_log_dir}${logname}
		echo "**************Unable to retrieve segment1 value from hive src_btch_id table"
		sh ${scripts}email_script.sh "Vision Prod:src_btch_id" "$email_send" "$email_receive" "While processing $foldername, unable to retrieving segment1 value from groupretiree_vision.src_btch_id table"     
		exit 0
	fi
	if [ -n "$segment1" ]; then
		echo "segment1 value is "$segment1
		else
		echo "segment1 value is empty"
		sh ${scripts}email_script.sh "Vision Prod:src_btch_id:$foldername Error occured" "$email_send" "$email_receive" "While processing $foldername, unable to retrieve segment1 value from groupretiree_vision.src_btch_id table.Please check whether processtype $vision exists in src_btch_id table"     	
		exit 0
	fi
segment2=$(hive -S -e  "select Numeric_Value from groupretiree_vision.src_btch_id where Segment_types='segment2' and Lookup_Value='${foldername}';")
	if [ $? -ne 0 ] #echo log if
		then 
		echo "NA|NA|NA|${DATE}|${TIME}|retrieving segment2 value from hive|Fail" &>> ${stat_log_dir}${logname}
		echo "**************Unable to retrieve segment2 value from hive src_btch_id table"
		sh ${scripts}email_script.sh "Vision Prod:src_btch_id" "$email_send" "$email_receive" "While processing $foldername, unable to retrieving segment2 value from groupretiree_vision.src_btch_id table"     
		exit 0
	fi
	if [ -n "$segment2" ]; then
		echo "segment2 value is "$segment2
	else
		echo "segment2 value is empty"
		sh ${scripts}email_script.sh "Vision Prod:src_btch_id:$foldername Error occured" "$email_send" "$email_receive" "While processing $foldername, unable to retrieve segment2 value from groupretiree_vision.src_btch_id table.Please check whether client_name $foldername exists in src_btch_id table"     	
		exit 0
	fi
segment3=$(hive -S -e  "select Numeric_Value from groupretiree_vision.src_btch_id where Segment_types='segment3' and Lookup_Value='${file_type}';")
	if [ $? -ne 0 ] #echo log if
		then 
		echo "NA|NA|NA|${DATE}|${TIME}|retrieving segment3 value from hive|Fail" &>> ${stat_log_dir}${logname}
		echo "**************Unable to retrieve segment3 value from hive src_btch_id table"
		sh ${scripts}email_script.sh "Vision Prod:src_btch_id" "$email_send" "$email_receive" "While processing $foldername, unable to retrieving segment3 value from groupretiree_vision.src_btch_id table"     
		exit 0
	fi
	if [ -n "$segment3" ]; then
		echo "segment3 value is "$segment3
	else
		echo "segment3 value is empty"
		sh ${scripts}email_script.sh "Vision Prod:src_btch_id:$foldername Error occured" "$email_send" "$email_receive" "While processing $foldername, unable to retrieving segment3 value from groupretiree_vision.src_btch_id table.Please check whether filetype $file_type exists in src_btch_id table"     	
		exit 0
	fi
batch_id=$segment1$segment2$segment3$MONTH$YEAR
	if [ $? -ne 0 ] #echo log if
		then 
		echo "NA|NA|NA|${DATE}|${TIME}|concatinating segmenttypes,month and year values to get batch_id|Fail" &>> ${stat_log_dir}${logname}
		echo "**************Unable to get batch_id value"
		sh ${scripts}email_script.sh "Vision Prod:src_btch_id" "$email_send" "$email_receive" "While processing $foldername, unable to get batch_id value"     
		exit 0
	fi
	if [ -n "$batch_id" ]; then
		echo "batch_id value is "$batch_id
	else
		echo "batch_id value is empty"
		sh ${scripts}email_script.sh "Vision Prod:src_btch_id:$foldername Error occured" "$email_send" "$email_receive" "While processing $foldername, unable to get batch_id value.Please check whether segment1,segment2,segment3,month and year values"     	
		exit 0
	fi
}
	
src_btch_id_Provider()
{
segment1=$(hive -S -e  "select Numeric_Value from groupretiree_vision.src_btch_id where Segment_types='segment1' and Lookup_Value='${vision}';")
	if [ $? -ne 0 ] #echo log if
		then 
		echo "NA|NA|NA|${DATE}|${TIME}|retrieving segment1 value from hive|Fail" &>> ${stat_log_dir}${logname}
		echo "**************Unable to retrieve segment1 value from hive src_btch_id table"
		sh ${scripts}email_script.sh "Vision Prod:src_btch_id" "$email_send" "$email_receive" "While processing $foldername, unable to retrieving segment1 value from groupretiree_vision.src_btch_id table"     
		exit 0
	fi
	if [ -n "$segment1" ]; then
		echo "segment1 value is "$segment1
		else
		echo "segment1 value is empty"
		sh ${scripts}email_script.sh "Vision Prod:src_btch_id:$foldername Error occured" "$email_send" "$email_receive" "While processing $foldername, unable to retrieve segment1 value from groupretiree_vision.src_btch_id table.Please check whether processtype $vision exists in src_btch_id table"     	
		exit 0
	fi
segment2=$(hive -S -e  "select Numeric_Value from groupretiree_vision.src_btch_id where Segment_types='segment2' and Lookup_Value='${foldername}';")
	if [ $? -ne 0 ] #echo log if
		then 
		echo "NA|NA|NA|${DATE}|${TIME}|retrieving segment2 value from hive|Fail" &>> ${stat_log_dir}${logname}
		echo "**************Unable to retrieve segment2 value from hive src_btch_id table"
		sh ${scripts}email_script.sh "Vision Prod:src_btch_id" "$email_send" "$email_receive" "While processing $foldername, unable to retrieving segment2 value from groupretiree_vision.src_btch_id table"     
		exit 0
	fi
	if [ -n "$segment2" ]; then
		echo "segment2 value is "$segment2
	else
		echo "segment2 value is empty"
		sh ${scripts}email_script.sh "Vision Prod:src_btch_id:$foldername Error occured" "$email_send" "$email_receive" "While processing $foldername, unable to retrieve segment2 value from groupretiree_vision.src_btch_id table.Please check whether client_name $foldername exists in src_btch_id table"     	
		exit 0
	fi
segment3=$(hive -S -e  "select Numeric_Value from groupretiree_vision.src_btch_id where Segment_types='segment3' and Lookup_Value='${file_type_prov}';")
	if [ $? -ne 0 ] #echo log if
		then 
		echo "NA|NA|NA|${DATE}|${TIME}|retrieving segment3 value from hive|Fail" &>> ${stat_log_dir}${logname}
		echo "**************Unable to retrieve segment3 value from hive src_btch_id table"
		sh ${scripts}email_script.sh "Vision Prod:src_btch_id" "$email_send" "$email_receive" "While processing $foldername, unable to retrieving segment3 value from groupretiree_vision.src_btch_id table"     
		exit 0
	fi
	if [ -n "$segment3" ]; then
		echo "segment3 value is "$segment3
	else
		echo "segment3 value is empty"
		sh ${scripts}email_script.sh "Vision Prod:src_btch_id:$foldername Error occured" "$email_send" "$email_receive" "While processing $foldername, unable to retrieving segment3 value from groupretiree_vision.src_btch_id table.Please check whether filetype $file_type exists in src_btch_id table"     	
		exit 0
	fi
batch_id=$segment1$segment2$segment3$MONTH$YEAR
	if [ $? -ne 0 ] #echo log if
		then 
		echo "NA|NA|NA|${DATE}|${TIME}|concatinating segmenttypes,month and year values to get batch_id|Fail" &>> ${stat_log_dir}${logname}
		echo "**************Unable to get batch_id value"
		sh ${scripts}email_script.sh "Vision Prod:src_btch_id" "$email_send" "$email_receive" "While processing $foldername, unable to get batch_id value"     
		exit 0
	fi
	if [ -n "$batch_id" ]; then
		echo "batch_id value is "$batch_id
	else
		echo "batch_id value is empty"
		sh ${scripts}email_script.sh "Vision Prod:src_btch_id:$foldername Error occured" "$email_send" "$email_receive" "While processing $foldername, unable to get batch_id value.Please check whether segment1,segment2,segment3,month and year values"     	
		exit 0
	fi
}

createtable_loaddata()
{
	#client folder is not there. create hive table based on vision type, create the client,year,month folder. move the file to the particular month folder and then call the alter script to loda the data into table
	echo "**************calling create table script"
	hive -f ${hivescripts}eyemed_cms_raw.hql -d client=$foldername
			if [ $? -ne 0 ] #echo log if
              then 
              echo "$f|$foldername|$visiontype|${DATE}|${TIME}|$foldername raw table creation failed|Fail" &>> ${stat_log_dir}${logname}
              echo "**************eyemed_cms_raw table creation failed"
              sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "eyemed_cms_raw.hql failed"     
              exit 0
            fi
	echo "$f|$foldername|$visiontype|${DATE}|${TIME}|Client table created|Pass" &>> ${stat_log_dir}${logname}
  echo "**************creating folder, year and month directory"
	mkdir -p $foldername/$YEAR/$MONTH
	echo "$f|$foldername|$visiontype|${DATE}|${TIME}|folders created|Pass" &>> ${stat_log_dir}${logname}
	echo "**************Moving Month folder"
			mkdir -p $location/$foldername/temp
            mv $landing/$f $location/$foldername/temp
			#mv $landing/$f $location/$foldername/$YEAR/$MONTH
            if [ $? -ne 0 ] #echo log if
              then 
              echo "$f|$foldername|$visiontype|${DATE}|${TIME}|Unable to move file|Fail" &>> ${stat_log_dir}${logname}
              echo "**************Moving $f from landing to month folder failed"
              sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "Moving $f from landing to temp folder failed"     
              exit 0
            fi
			file_extention_check_alter_table $f $foldername $visiontype $logname &>> ${log_dir}${logname}
			if [ $? -ne 0 ] #echo log if
            	    then 
            	    sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "Failure in the eyemed_rawtable.sh script"     
                  exit 0
   			fi
#getting src_btch_id for vision claims
			src_btch_id_claims $file_type
			if [ $? -ne 0 ] #echo log if
            	    then 
            	    sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "Failure while getting src_btch_id"     
                  exit 0
   			fi
#getting client_name from cilent_file_info to map ORIG_SUB_SRC_SYS field
			client_name=$(hive -S -e  "select client_name from groupretiree_vision.client_file_info where layout='${eyemed_cms}' and folder_name='${foldername}' limit 1;")
  			if [ $? -ne 0 ] #echo log if
            	    then 
            	    sh ${scripts}email_script.sh "Vision Prod:client_name:$foldername Error occured" "$email_send" "$email_receive" "Failure while getting client_name from client_file_info table"     
                  exit 0
   			fi
			echo "client name is " $client_name
#loading vision claims clean data to acc_vision table
			hive -f ${hivescripts}eyemed_cms_claims_insert.hql -d year=$YEAR -d month=$MONTH -d client=$foldername -d client_name=$client_name -d date=$DATE -d src_batch_id=$batch_id
			if [ $? -ne 0 ] #echo log if
               then 
               echo "$f|$foldername|$pbmtype|${DATE}|${TIME}|eyemed_cms_claims_insert.hql failed|Fail" &>> ${stat_log_dir}${logname}
               echo "**************Failed to execute eyemed_cms_claims_insert.hql"
               sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "eyemed_cms_claims_insert.hql script failed"
               exit 0
            fi
#loading distinct fields data into ${client}_prov_raw table 
			hive -f ${hivescripts}eyemed_cms_prov_raw.hql -d year=$YEAR -d month=$MONTH -d client=$foldername
				if [ $? -ne 0 ] #echo log if
					then 
					echo "$f|$foldername|$pbmtype|${DATE}|${TIME}|eyemed_cms_prov_raw.hql failed|Fail" &>> ${stat_log_dir}${logname}
					echo "**************Failed to execute eyemed_cms_prov_raw.hql"
					sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "eyemed_cms_prov_raw.hql failed"
					exit 0
				fi
#retrieving src_batch_id for provider table
			src_btch_id_Provider $file_type_prov
				if [ $? -ne 0 ] #echo log if
            	    then 
            	    sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "Failure while getting src_btch_id"     
					exit 0
				fi
#loading prov_raw table to acc_provider table
		hive -f ${hivescripts}eyemed_cms_provider_insert.hql -d year=$YEAR -d month=$MONTH -d client=$foldername -d client_name=$client_name -d date=$DATE -d src_batch_id=$batch_id
			if [ $? -ne 0 ] #echo log if
               then 
               echo "$f|$foldername|$pbmtype|${DATE}|${TIME}|eyemed_cms_provider_insert.hql failed|Fail" &>> ${stat_log_dir}${logname}
               echo "**************Failed to execute eyemed_cms_provider_insert.hql"
               sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "eyemed_cms_provider_insert.hql failed"
               exit 0
            fi
}
	
eyemed_loaddata()
{
	echo "************In eyemed function, file name is $f,visiontype is $visiontype"
	if [[ -d $foldername ]] ; then		#check for folder name
	    echo "************Client, type1 and type2 folder exists"
		cd $location/$foldername/type1 #change the type1
	    echo "************eyemed_foldercheck function called"
	    echo "$f|$foldername|$visiontype|${DATE}|${TIME}|eyemed_foldercheck called|Pass" &>> ${stat_log_dir}${logname}
		eyemed_foldercheck $foldername "type1"		#call the alter script repeat the same process for type2
		cd $location/$foldername/type2
		eyemed_foldercheck $foldername "type2"	
	    echo "************eyemed_split function called"	
	    echo "$f|$foldername|$visiontype|${DATE}|${TIME}|eyemed_foldercheck called|Pass" &>> ${stat_log_dir}${logname}
		eyemed_split $f $foldername		#call the split function to split the file and move the file to appropriate type
	else
		#if the folder is not there create directories,tables,split the file and call the alter scripts
		echo "************Client folder does not exist"
		echo "************Create table for type1 called"
		echo "$f|$foldername|$visiontype|${DATE}|${TIME}|eyemed_type1_raw.hql called|Pass" &>> ${stat_log_dir}${logname}
		hive -f ${hivescripts}eyemed_type1_raw.hql -d client=$foldername
		    if [ $? -ne 0 ] #echo log if
              then 
              echo "$f|$foldername|$visiontype|${DATE}|${TIME}|eyemed_type1_raw.hql failed|Fail" &>> ${stat_log_dir}${logname}
              echo "**************eyemed_type1_raw.hql failed"
              exit 40
            fi
		echo "************type1 table created successfully"
		echo "************Create table for type2 called"
		echo "$f|$foldername|$visiontype|${DATE}|${TIME}|eyemed_type2_raw.hql called|Pass" &>> ${stat_log_dir}${logname}
		hive -f ${hivescripts}eyemed_type2_raw.hql -d client=$foldername
		    if [ $? -ne 0 ] #echo log if
              then 
              echo "$f|$foldername|$visiontype|${DATE}|${TIME}|eyemed_type2_raw.hql failed|Fail" &>> ${stat_log_dir}${logname}
              echo "**************eyemed_type1_raw.hql failed"
              exit 40
            fi
		echo "************type2 table created successfully"
		
		echo "************Create client, type, year and month folders"
		mkdir -p $foldername/type1/$YEAR/$MONTH
		mkdir -p $foldername/type2/$YEAR/$MONTH
		echo "$f|$foldername|$visiontype|${DATE}|${TIME}|folders created|Pass" &>> ${stat_log_dir}${logname}
		echo "************Folders created successfully"
		echo "************eyemed_split function called"
		echo "$f|$foldername|$visiontype|${DATE}|${TIME}|eyemed_split called|Pass" &>> ${stat_log_dir}${logname}
		eyemed_split $f $foldername
	fi
		echo "************calling type1 alter table script"
		cd $location
		hive -f ${hivescripts}eyemed_type1_alter.hql -d year=$YEAR -d month=$MONTH -d client=$foldername -d path=$hive_alterpath
		    if [ $? -ne 0 ] #echo log if
              then 
              echo "$f|$foldername|$visiontype|${DATE}|${TIME}|eyemed_type1_alter.hql failed|Fail" &>> ${stat_log_dir}${logname}
              echo "**************eyemed_type1_alter.hql failed"
              exit 40
            fi
		echo "$f|$foldername|$visiontype|${DATE}|${TIME}|type1 partition added|Pass" &>> ${stat_log_dir}${logname}
		echo "************Partition for type1 successfully added"
		echo "************calling type2 alter table script"
		hive -f ${hivescripts}eyemed_type2_alter.hql -d year=$YEAR -d month=$MONTH -d client=$foldername -d path=$hive_alterpath
		    if [ $? -ne 0 ] #echo log if
              then 
              echo "$f|$foldername|$visiontype|${DATE}|${TIME}|eyemed_type2_alter.hql failed|Fail" &>> ${stat_log_dir}${logname}
              echo "**************eyemed_type2_alter.hql failed"
              exit 40
            fi
		echo "$f|$foldername|$visiontype|${DATE}|${TIME}|type2 partition added|Pass" &>> ${stat_log_dir}${logname}
		echo "************Partition for type2 successfully added"
#getting src_btch_id for $foldername vision claims
		src_btch_id_claims $file_type
			if [ $? -ne 0 ] #echo log if
            	    then 
            	    sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "Failure while getting src_btch_id"     
                  exit 0
   			fi
#getting client_name from cilent_file_info to map ORIG_SUB_SRC_SYS field for $foldername
			client_name=$(hive -S -e  "select client_name from groupretiree_vision.client_file_info where layout='${eyemed}' and folder_name='${foldername}' limit 1;")
  			if [ $? -ne 0 ] #echo log if
            	    then 
            	    sh ${scripts}email_script.sh "Vision Prod:client_name:$foldername Error occured" "$email_send" "$email_receive" "Failure while getting client_name from client_file_info table for $foldername client"     
                  exit 0
   			fi
			echo "client name is " $client_name
#loading vision claims data into acc_vision table 
		hive -f ${hivescripts}eyemed_claims_insert.hql -d year=$YEAR -d month=$MONTH -d client=$foldername -d client_name=$client_name -d date=$DATE -d src_batch_id=$batch_id
			if [ $? -ne 0 ] #echo log if
               then 
               echo "$f|$foldername|$pbmtype|${DATE}|${TIME}|eyemed_claims_insert.hql failed|Fail" &>> ${stat_log_dir}${logname}
               echo "**************Failed to execute eyemed_claims_insert.hql"
               sh ${scripts}email_script.sh "Vision Prod:eyemed:$foldername claims script failed" "$email_send" "$email_receive" "eyemed_claims_insert.hql failed"
               exit 0
            fi
#loading distinct fields data into ${client}_prov_raw table 
		hive -f ${hivescripts}eyemed_prov_raw.hql -d year=$YEAR -d month=$MONTH -d client=$foldername
		    if [ $? -ne 0 ] #echo log if
               then 
               echo "$f|$foldername|$pbmtype|${DATE}|${TIME}|eyemed_prov_raw.hql failed|Fail" &>> ${stat_log_dir}${logname}
               echo "**************Failed to execute eyemed_prov_raw.hql"
               sh ${scripts}email_script.sh "Vision Prod:eyemed:$foldername script failed" "$email_send" "$email_receive" "eyemed_prov_raw.hql failed"
               exit 0
            fi
#retrieving src_batch_id for provider table
			src_btch_id_Provider $file_type_prov
				if [ $? -ne 0 ] #echo log if
            	    then 
            	    sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "Failure while getting src_btch_id for $foldername provider table"     
					exit 0
				fi
#loading prov_raw table to acc_provider table
		hive -f ${hivescripts}eyemed_provider_insert.hql -d year=$YEAR -d month=$MONTH -d client=$foldername -d client_name=$client_name -d date=$DATE -d src_batch_id=$batch_id
			if [ $? -ne 0 ] #echo log if
               then 
               echo "$f|$foldername|$pbmtype|${DATE}|${TIME}|eyemed_provider_insert.hql failed|Fail" &>> ${stat_log_dir}${logname}
               echo "**************Failed to execute eyemed_provider_insert.hql"
               sh ${scripts}email_script.sh "Vision Prod:eyemed:$foldername provider script failed" "$email_send" "$email_receive" "eyemed_provider_insert.hql failed"
               exit 0
            fi	
}
	
eyemed_foldercheck()
{
	#this function confirms that the directory structure inside segments is appropriate
	if [[ -d $YEAR ]] ; then
	echo "**************In $2 Year folder exists"
	cd $location/$foldername/$2/$YEAR
        if [[ ! -d $MONTH ]] ; then
        echo "**************Creating month folder"      
		mkdir $MONTH
		echo "$f|$foldername|$visiontype|${DATE}|${TIME}|month folder created|Pass" &>> ${stat_log_dir}${logname}
		echo "**************Folder created"
		fi
        else
        	    echo "**************create year and month folders"
                mkdir -p $YEAR/$MONTH
                echo "$f|$foldername|$visiontype|${DATE}|${TIME}|folders created|Pass" &>> ${stat_log_dir}${logname}
                echo "**************Folders created"
    fi	
}

eyemed_split()
{
	#function to split the file and move it appropriate folders
	echo "************Inside eyemed split function"
	cd $location/$foldername
	mkdir -p temp
	echo "************moving $f to temp folder"
	cp $landing/$f $location/$foldername/temp
	    if [ $? -ne 0 ] #echo log if
            then 
            echo "$f|$foldername|$visiontype|${DATE}|${TIME}|move $f to temp folder|Fail" &>> ${stat_log_dir}${logname}
            echo "**************Moving $f from landing to temp folder failed"
            exit 40
        fi
	echo "$f|$foldername|$visiontype|${DATE}|${TIME}|file moved to temp folder|Pass" &>> ${stat_log_dir}${logname}
	echo "************$f successfully moved to temp"
	# archieve starts
	echo "************Archival process starts"
	cd $archive	#take backup of the original file from landing zone and save it in the archive
	if [[ -d $foldername ]] ; then
		mv $landing/$f $archive/$foldername 
	    if [ $? -ne 0 ] #echo log if
            then 
            echo "$f|$foldername|$visiontype|${DATE}|${TIME}|copying $f to archive folder|Fail" &>> ${stat_log_dir}${logname}
            echo "**************copying $f from landing to archive folder failed"
            exit 40
        fi
	else
		echo "$f|$foldername|$visiontype|${DATE}|${TIME}|archival folder created|Pass" &>> ${stat_log_dir}${logname}
		mkdir $foldername
		mv $landing/$f $archive/$foldername
		if [ $? -ne 0 ] #echo log if
            then 
            echo "$f|$foldername|$visiontype|${DATE}|${TIME}|copying $f to archive folder|Fail" &>> ${stat_log_dir}${logname}
            echo "**************copying $f from landing to archive folder failed"
            exit 40
        fi
	fi
	echo "$f|$foldername|$visiontype|${DATE}|${TIME}|archival complete|Pass" &>> ${stat_log_dir}${logname}
    echo "************Archival process ends"
	#archieve ends
    cd $location/$foldername/temp
	file=`ls $location/$foldername/temp`
    echo "************Checking file extension"
	extension="${file##*.}"
	echo "************extension of the file is $extension"
	if [[ $extension == 'gz' ]] ; then
		    echo "************gunzipping $file"
        	gunzip $file
        	if [ $? -ne 0 ] #echo log if
            then 
            echo "$f|$foldername|$visiontype|${DATE}|${TIME}|gunzipping $file|Fail" &>> ${stat_log_dir}${logname}
            echo "**************gunzipping $file failed"
            exit 40
            fi
	elif [[ $extension == 'zip' ]] ; then
            echo "************unzipping $file"
		    unzip $file
		    if [ $? -ne 0 ] #echo log if
            then 
            echo "$f|$foldername|$visiontype|${DATE}|${TIME}|unzipping $file|Fail" &>> ${stat_log_dir}${logname}
            echo "**************unzipping $file failed"
            exit 40
            fi
		    echo "************Removing original zip file"
		    rm $file
	fi	
	echo "$f|$foldername|$visiontype|${DATE}|${TIME}|unzip/gunzip checked|Pass" &>> ${stat_log_dir}${logname}
        file=`ls $location/$foldername/temp`
    echo "************Splitting $file to type1 and type 2 folders"
	awk -F, '{if($1>0 && $1<2)print > "type1.txt"}' $file
    if [ $? -ne 0 ] #echo log if
            then 
            echo "$f|$foldername|$visiontype|${DATE}|${TIME}|splitting file into type1 part|Fail" &>> ${stat_log_dir}${logname}
            echo "**************splitting file into type1 part failed"
            exit 40
    fi
	awk -F, '{if($1>2 && $1<3)print > "type2.txt"}' $file
	#awk '{print > substr($0, 1, 2)}' $file
    if [ $? -ne 0 ] #echo log if
            then 
            echo "$f|$foldername|$visiontype|${DATE}|${TIME}|splitting file into type2 part|Fail" &>> ${stat_log_dir}${logname}
            echo "**************splitting file into type2 part failed"
            exit 40
    fi
	echo "$f|$foldername|$visiontype|${DATE}|${TIME}|file split complete|Pass" &>> ${stat_log_dir}${logname}
	echo "************Split successful"
	echo "************Moving file from type1,type2 to month directory"
	mv type1.txt $location/$foldername/type1/$YEAR/$MONTH/type1_$file
	if [ $? -ne 0 ] #echo log if
            then 
            echo "$f|$foldername|$visiontype|${DATE}|${TIME}|moving type1.txt to month folder|Fail" &>> ${stat_log_dir}${logname}
            echo "**************moving type1.txt to month folder failed"
            exit 40
    fi
	mv type2.txt $location/$foldername/type2/$YEAR/$MONTH/type2_$file
	if [ $? -ne 0 ] #echo log if
            then 
            echo "$f|$foldername|$visiontype|${DATE}|${TIME}|moving type2.txt to month folder|Fail" &>> ${stat_log_dir}${logname}
            echo "**************moving type2.txt to month folder failed"
            exit 40
    fi
	echo "$f|$foldername|$visiontype|${DATE}|${TIME}|files moved from temp|Pass" &>> ${stat_log_dir}${logname}
	echo "************Files successfully moved"
    echo "************Cleaning temp folder"
    #rm $file
	echo "removing temp folder"
	rm -rf $location/$foldername/temp
    if [ $? -ne 0 ] #echo log if
            then 
            echo "$f|$foldername|$visiontype|${DATE}|${TIME}|removing temp folder|Fail" &>> ${stat_log_dir}${logname}
            echo "**************removing $file from temp folder"
            exit 40
    fi
		
    echo "$f|$foldername|$visiontype|${DATE}|${TIME}|temp folder removed|Pass" &>> ${stat_log_dir}${logname}
    echo "************Cleaning complete"
	echo "loading client name to client_lists file"
	grep -q -F $foldername $result/clients_list.txt || echo $foldername >> $result/clients_list.txt
    if [ $? -ne 0 ] #echo log if
            then 
            echo "$f|$foldername|$visiontype|${DATE}|${TIME}|adding client name to clients_lists file|Fail" &>> ${stat_log_dir}${logname}
            echo "**************moving type2.txt to month folder failed"
            exit 40
    fi

	echo "************client name added to clients_list.txt file"
}
	
for f in $filelist	#processing of files one by one
	do
	  echo "$f|NA|NA|${DATE}|${TIME}|$f picked|Pass" &>> ${stat_log_dir}${logname}		
		echo "processing of $f has started"
		echo "**************processing of $f has started" &>> ${log_dir}${logname}
		flag=0
		for stringmatch in `cat $result/string_patterns.txt` 	#pick string patterns stored earlier
		do
        echo "current string pattern is $stringmatch" &>> ${log_dir}${logname}
        if [[ $f == $stringmatch ]] ; then	#loop for string match, if there is any string match, process that file    
				  echo "**************$f matched with string $stringmatch" &>> ${log_dir}${logname}
				  echo "$f|NA|NA|${DATE}|${TIME}|$f matched|Pass" &>> ${stat_log_dir}${logname}
				  flag=1 
				  query_clientsreference &>> ${log_dir}${logname}
				  #read foldername visiontype <<< $(hive -e "select folder_name,layout from groupretiree_vision.client_file_info where file_naming_convention='$stringmatch';")				
				  echo "$f|$foldername|$visiontype|${DATE}|${TIME}|Reference table queryed|Pass" &>> ${stat_log_dir}${logname}
				  cd $location	
				  #if visiontype is eyemed then process the file differently
				if [[ $visiontype == $eyemed ]] ; then
					echo "vision type is EyeMed"
					#export f foldername visiontype 	
					echo "**************Calling eyemed layout script" &>> ${log_dir}${logname}
					echo "$f|$foldername|$visiontype|${DATE}|${TIME}|pfizer_rawtable script called|Pass" &>> ${stat_log_dir}${logname}
					eyemed_loaddata $f $foldername $visiontype $logname &>> ${log_dir}${logname}
					if [ $? -ne 0 ] #echo log if
            	    then 
            	    sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "Failure while loading eyemed data into client specific folder"     
                  exit 0
   					fi					
				
				elif [[ $visiontype == $eyemed_cms ]] ; then
						echo "vision type is EyeMed_CMS"
					if [[ -d $foldername ]] ; then
						echo "$f|$foldername|$visiontype|${DATE}|${TIME}|movefile_loaddata script called|Pass" &>> ${stat_log_dir}${logname}
						movefile_loaddata $f $foldername   &>> ${log_dir}${logname}	#If the client folder name is already there then just move the file to the appropriate folder
						if [ $? -ne 0 ] #echo log if
						then 
						sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "Failure while loading illinois data into client specific folder"     
						exit 0
						fi
					else
						echo "$f|$foldername|$visiontype|${DATE}|${TIME}|createtable_loaddata script called|Pass" &>> ${stat_log_dir}${logname}
						createtable_loaddata $f $foldername $visiontype   &>> ${log_dir}${logname}	#if the client folder is not there then create client directory, table and move the file to the appropriate folder
						if [ $? -ne 0 ] #echo log if
						then 
						sh ${scripts}email_script.sh "$EMAIL_SUB" "$email_send" "$email_receive" "Failure while creating and loading data into illinois table"     
						exit 0
						fi
					fi
				else "unknown vision type"
				fi
			fi
		done
		if [[ $flag == 0 ]] ; then
			echo "**************$f unknown file found" &>> ${log_dir}${logname}
			mv $landing/$f $unknown_files 
			echo "$f|NA|NA|${DATE}|${TIME}|Unknown file moved|Pass" &>> ${stat_log_dir}${logname}
			sh ${scripts}email_script.sh "Vision Prod:Unknown file received" "$email_send" "$email_receive" "Unknown file received in the Vision landing zone. Moved to unknown_files folder $unknown_files/$f "     
		fi
        done


